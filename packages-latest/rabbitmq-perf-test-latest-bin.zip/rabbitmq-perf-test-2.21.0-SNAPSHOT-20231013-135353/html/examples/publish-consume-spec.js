[{'name':      'consume',
  'type':      'simple',
  'params':    [{'time-limit':     30,
                 'producer-count': 4,
                 'consumer-count': 2}]}]